﻿using System;

namespace EJERCICIOhilos
{
    using System;
    using System.Numerics;
    using System.Threading;

    /* Crea dos hilos que cuentan hasta 5 con diferentes tiempos de espera.
     * 
     *      Mostrar por consola:
     *          - Nombre del hilo más el numero por el que va contando
     *          - Cuando ambos acaben: "Ambos hilos han terminado"
     * Pista: Para aplicar tiempos de espera usad Thread.Sleep(milisegundos) // miliseconds
     */

    internal class Program
    {
        static void Main(string[] args)
        {
            Thread t1 = new Thread(CuentaHastaCinco);
            Thread t2 = new Thread(CuentaHastaCinco);

            t1.Name = "Hilo 1";
            t2.Name = "Hilo 2";

            t1.Start(200);
            t2.Start(500);

            t1.Join();
            t2.Join();

            Console.WriteLine("Ambos hilos han terminado");
        }

        static void CuentaHastaCinco(object espera)
        {
            int esperaCasteada = (int)espera;
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine($"{Thread.CurrentThread.Name}: {i}");
                Thread.Sleep(esperaCasteada);
            }
        }
    }
}
