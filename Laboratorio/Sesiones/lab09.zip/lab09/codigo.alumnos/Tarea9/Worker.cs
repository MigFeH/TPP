﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Lab09
{
    public class Worker
    {
        // el worker trabaja con un subconjunto de datos del array de datos
        private BitcoinValueData[] arrayDatos;
        private int valorSuministrado;
        
        private int indiceInicial;
        private int indiceFinal;

        private int result;
        public int Result { get { return result; } }

        public Worker(BitcoinValueData[] arrayDatos, int valorSuministrado, int indiceInicial, int indiceFinal)
        {
            this.arrayDatos = arrayDatos;
            this.valorSuministrado = valorSuministrado;
            this.indiceInicial = indiceInicial;
            this.indiceFinal = indiceFinal;
            this.result = 0;
        }

        public void Compute()
        {
            // computamos el nº de veces que el valor del bitcoin ha sido mayor o igual que dicho valor suministrado
            for(int i = indiceInicial; i <= indiceFinal; i++)
            {
                if (arrayDatos[i].Value >= valorSuministrado)
                {
                    result++;
                }
            }
        }
    }
}
