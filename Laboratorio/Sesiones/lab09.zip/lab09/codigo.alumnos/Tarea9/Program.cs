﻿using System;


namespace Lab09
{

    class Program
    {
        /*
         * This program processes Bitcoin value information obtained from the
         * url https://api.kraken.com/0/public/OHLC?pair=xbteur&interval=5.
         */
        static void Main(string[] args)
        {
            var data = Utils.GetBitcoinData();
            //foreach (var d in data)
            //    Console.WriteLine(d);

            /* Implementar una aplicación que calcule de forma concurrente el nº de veces que el valor
             * del Bitcoin está por encima de un valor prefijado (que se pasa como parámetro al Master) 
             * en el array de valores que se proporciona.
             * 
             * El Master debe devolver el nº de veces que el valor del bitcoin ha sido mayor o igual que dicho valor suministrado.
             * Por ejemplo, en el periodo en el que se suministran los datos, el Bitcoin ha estado por encima de los 7000 euros 2826 veces.
             */
            int valorSuministrado = 7000;
            Master master = new Master(data, valorSuministrado, 4); // el master subdivide el tamanio del problema y asgina cada subproblema a un hilo
            int result = master.Compute();
            Console.WriteLine($"El Bitcoin ha estado por encima de los {valorSuministrado} euros unas {result} veces");

            /* Llamar a GC.Collect() y GC.WaitForFullGCComplete() después de cada ejecución del algoritmo. */
            GC.Collect(); // fuerza al colector de basura de todas las generaciones
            GC.WaitForFullGCComplete();
        }
    }
}
