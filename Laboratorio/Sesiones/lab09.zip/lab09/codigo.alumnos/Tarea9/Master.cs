﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Lab09
{
    public class Master
    {
        private BitcoinValueData[] arrayDatos;
        private int valorSuministrado;
        private int numberOfThreads;

        public Master(BitcoinValueData[] arrayDatos, int valorSuministrado, int numberOfThreads)
        {
            this.arrayDatos = arrayDatos;
            this.valorSuministrado = valorSuministrado;
            this.numberOfThreads = numberOfThreads;
        }

        public int Compute()
        {
            // creamos un array de workers de tamanio == numberOfThreads
            Worker[] workers = new Worker[numberOfThreads];

            // repartimos los elementos a computar del array para cada worker
            int itemsPerWorker = arrayDatos.Length / numberOfThreads;

            // creamos los objetos workers del array de workers y le pasamos el array con el que va a trabajar y los indices de este con los que va a trabajar
            for(int i = 0; i < numberOfThreads; i++)
            {
                workers[i] = new Worker(arrayDatos,
                                        valorSuministrado,
                                        i*itemsPerWorker,
                                        (i < numberOfThreads-1) ? (i+1)*itemsPerWorker-1 : arrayDatos.Length-1 /* el ultimo indice */);
            }

            // creamos un array de hilos en el que cada hilo trabaja cada computacion de los workers
            Thread[] threads = new Thread[workers.Length];

            for(int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(workers[i].Compute);
                threads[i].Name = "Hilo numero " + (i + 1);
                threads[i].Start();
            }

            // despues de crear cada uno de los hilos y ponerlos a ejecutar...
            for(int i = 0; i < threads.Length; i++)
            {
                // hacemos que cada hilo espere a que termine su ejercucion
                threads[i].Join();
            }

            int result = 0; // el valor que vamos a retornar tras la ejecucion
            foreach(Worker w in workers)
            {
                result += w.Result;
            }

            return result;
        }
    }
}
