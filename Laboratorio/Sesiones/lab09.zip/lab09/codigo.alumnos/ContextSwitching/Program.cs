﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;

namespace Lab09
{
    internal class Program
    {
        [DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

        static void Main(string[] args)
        {
            /* Medir el context switching, analizando cuando se obtiene el máximo beneficio al utilizar
             * varios hilos y el punto en el que el coste es mayor que la solución secuencial. */

            var data = Utils.GetBitcoinData();
            int valorSuministrado = 7000;
            const int maxNumberOfThreads = 50;
            ShowLine(Console.Out, "Number of threads", "Ticks", "Result");
            for(int i = 1; i <= maxNumberOfThreads; i++)
            {
                Master master = new Master(data, valorSuministrado, i); // el master subdivide el tamanio dle problema y asigna cada subproblema a un worker que tendra el metodo que ejecutara cada hilo
                long before = 0;
                QueryPerformanceCounter(out before);
                int result = master.Compute();
                long after = 0;
                QueryPerformanceCounter(out after);
                ShowLine(Console.Out, i, (after - before), result);
                //Console.WriteLine($"Number of threads: {i} | Ticks: {after - before} | Result: {result}");

                /* Llamar a GC.Collect() y GC.WaitForFullGCComplete() después de cada ejecución del algoritmo. */
                GC.Collect(); // fuerza al colector de basura de todas las generaciones
                GC.WaitForFullGCComplete();
            }
        }

        private const string CSV_SEPARATOR = ";";

        static void ShowLine(TextWriter stream, string numberOfThreadsTitle, string ticksTitle, string resultTitle)
        {
            stream.WriteLine("{0}{3}{1}{3}{2}{3}", numberOfThreadsTitle, ticksTitle, resultTitle, CSV_SEPARATOR);
        }

        static void ShowLine(TextWriter stream, int numberOfThreads, long ticks, double result)
        {
            stream.WriteLine("{0}{3}{1:N0}{3}{2:N2}{3}", numberOfThreads, ticks, result, CSV_SEPARATOR);
        }
    }
}
