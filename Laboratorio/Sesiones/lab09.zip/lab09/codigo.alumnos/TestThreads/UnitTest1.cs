using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Lab09
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var data = Utils.GetBitcoinData();
            int valorSuministrado = 7000;

            int valorEsperado = 0;
            for(int i = 0; i < data.Length; i++)
            {
                if (data[i].Value >= valorSuministrado)
                {
                    valorEsperado++;
                }
            }

            Master master = new Master(data, valorSuministrado, 4);
            Assert.AreEqual(valorEsperado, master.Compute());

            /* Llamar a GC.Collect() y GC.WaitForFullGCComplete() despu�s de cada ejecuci�n del algoritmo. */
            GC.Collect(); // fuerza al colector de basura de todas las generaciones
            GC.WaitForFullGCComplete();
        }
    }
}
