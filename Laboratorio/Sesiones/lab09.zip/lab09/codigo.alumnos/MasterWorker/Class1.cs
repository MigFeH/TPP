﻿using System;

namespace MasterWorker
{
    public class Class1
    {
    }
}
