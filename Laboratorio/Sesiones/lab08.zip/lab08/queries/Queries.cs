﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TPP.Laboratory.Functional.Lab08 {

    class Query {

        private Model model = new Model();

        private static void Show<T>(IEnumerable<T> collection) {
            foreach (var item in collection) {
                Console.WriteLine(item);
            }
            Console.WriteLine("Number of items in the collection: {0}.", collection.Count());
        }

        static void Main(string[] args) {
            Query query = new Query();
            //query.Query1();
            //query.Query2();
            //query.Query3();
            //query.Query4();
            //query.Query5();
            //query.Query6();
            query.Homework1();
            query.Homework2();
            query.Homework3();
            query.Homework4();
            query.Homework5();
        }

        private void Query1() {
            // Modify this query to show the names of the employees older than 50 years
            var employees = model.Employees;
            var res = employees.Where((empleado) => empleado.Age > 50);
            Console.WriteLine("Employees:");
            Show(res);
            Show(employees);
        }

        private void Query2() {
            // Show the name and email of the employees who work in Asturias
            var employees = model.Employees;
            var res = employees.Where((empleado) => empleado.Province.Equals("Asturias")).Select((empleado) => empleado.Name + " " + empleado.Email);
            Console.WriteLine("Employees:");
            Show(res);
            Show(employees);
        }

        // Notice: from now on, check out http://msdn.microsoft.com/en-us/library/9eekhta0.aspx

        private void Query3() {
            // Show the names of the departments with more than one employee 18 years old and beyond; 
            // the department should also have any office number starting with "2.1"
            var departaments = model.Departments;
            var employees = model.Employees;

            var resDepartamentos = departaments.Where(
                (departamento) => departamento.Employees
                .Where((empleado) => empleado.Age >= 18)
                    .Aggregate(0, (acc, empleado) => acc + 1) > 1 &&
                departamento.Employees.Any((empleado) => empleado.Office.Number.Equals("2.1")));
            Console.WriteLine("Departments:");
            Show(resDepartamentos);
            Show(employees);

        }

        private void Query4() {
            // Show the phone calls of each employee. 
            // Each line should show the name of the employee and the phone call duration in seconds.
            var employees = model.Employees;
            var calls = model.PhoneCalls;

            var res = employees.Join(calls /* la lista con la que enlazo */,
                empleado => empleado.TelephoneNumber /* la clave que quiero que se iguale por parte de los empleados */,
                llamada => llamada.SourceNumber /* la clave que quiero que se iguale por parte de las llamadas */,
                (empleado, llamada) => new { name = empleado.Name, duracion = llamada.Seconds } /* la funcion que crea una nueva lista con lo que nos piden*/);
            Show(res);

        }

        private void Query5() {
            // Show, grouped by each province, the name of the employees 
            // (both province and employees must be lexicographically ordered)
            var employees = model.Employees;
            //var empleadosAgrupados = employees.GroupBy((empleado) => empleado.Province /* el empleado.Province se guarda implicitamente em key de LINQ*/);
            //var res = empleadosAgrupados.OrderBy(empleado => empleado.Key); // el order by ordena todos los campos por defecto
            //Show(res);

            var res = employees.OrderBy(empleado => empleado.Province)
                .ThenBy(empleado => empleado.Name)
                .GroupBy(empleado => empleado.Province);
            Show(res);
        }

        private void Query6()
        {
            // Rank the calls by duration. Show rank position and duration
            var calls = model.PhoneCalls;
            var res = calls.OrderByDescending(llamada => llamada.Seconds);

            int index = 1;
            foreach (PhoneCall x in res)
            {
                Console.WriteLine($"Rank {index++}: {x.Seconds} seconds");
            }
        }


        /************ Homework **********************************/

        private void Homework1() {
            // Show, ordered by age, the names of the employees in the Computer Science department, 
            // who have an office in the Faculty of Science, 
            // and who have done phone calls longer than one minute
            var employees = model.Employees;
            var calls = model.PhoneCalls;

            var res = employees
                .Where(empl => empl.Department.Name == "Computer Science")
                .Where(empl => empl.Office.Building == "Faculty of Science")
                .Where(/* recibimos el empleado */ empl => calls.Any(call => call.SourceNumber == empl.TelephoneNumber || call.DestinationNumber == empl.TelephoneNumber && call.Seconds > 60))
                .OrderBy(empl => empl.Age)
                .Select(empl => empl.Name);
            Show(res);
        }

        private void Homework2() {
            // Show the summation, in seconds, of the phone calls done by the employees of the Computer Science department
            var employees = model.Employees;
            var calls = model.PhoneCalls;

            int res = calls.Join(employees.Where(emp => emp.Department.Name == "Computer Science"),
                call => call.SourceNumber,
                emp => emp.TelephoneNumber,
                (call, empl) => new { time = call.Seconds })
                .Aggregate(0, (acc, a) => acc + a.time);

            Console.WriteLine($"Suma de los segundos = {res}");
        }

        private void Homework3() {
            // Show the phone calls done by each department, ordered by department names. 
            // Each line must show “Department = <Name>, Duration = <Seconds>”
            var calls = model.PhoneCalls;
            var employees = model.Employees;

            // llamada (empleado) departamento
            var res = calls.Join(employees,
                call => call.SourceNumber,
                emp => emp.TelephoneNumber,
                (call, emp) => new { Departament = emp.Department.Name, Duration = call.Seconds })
                .OrderBy(a => a.Departament);

            foreach (var x in res)
            {
                Console.WriteLine($"Departament = {x.Departament}, Duration = {x.Duration}");
            }
        }

        private void Homework4() {
            // Show the departments with the youngest employee, 
            // together with the name of the youngest employee and his/her age 
            // (more than one youngest employee may exist)
            var departaments = model.Departments;
            var employees = model.Employees;

            var youngest = employees.Where(empl => empl.Age == employees.Select(em => em.Age).Min()); // los empleados mas jovenes

            var res = youngest.OrderBy(you => you.Department.Name)
                .Select(you => you.Department.Name + " " + you.Name + " " + you.Age); // los departamentos a los que pertenece cada empleado mas joven

            Show(res);
        }

        private void Homework5() {
            // Show the greatest summation of phone call durations, in seconds, 
            // of the employees in the same department, together with the name of the department 
            // (it can be assumed that there is only one department fulfilling that condition)
            var departaments = model.Departments;
            var calls = model.PhoneCalls;

            // tenemos que devolver una tupla con el nombre del departamento y la suma maxima de las duraciones de las llamadas (hacer un join entre los empleados del departamento y las llamadas por el SourceNumber y el TelephoneNumber; seguido de un Sum() que nos sumará los segundos de cada empleado del departamento; y al final hacerle a la tupla que se devuelve un Max() que hará el máximo del primer campo de la tupla)
            var res = departaments
                .Select(dep => (dep.Employees.Join(calls, e => e.TelephoneNumber, c => c.SourceNumber, (e, c) => c.Seconds).Sum(), dep.Name)).Max();

            Console.WriteLine($"{res.Name}, {res.Item1}");
        }
    }

}
