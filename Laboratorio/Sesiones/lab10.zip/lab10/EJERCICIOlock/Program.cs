﻿using System;
using System.Threading;

namespace EJERCICIOlock
{
    /* 
     * Aplicacion que genere 2 hilos que incrementan y decrementan un contador de forma simultánea, evitando problemas de concurrencia.
     * 
     *      - CADA HILO: y llamar al metodo que corresponda 100 veces, esperar 100 ms entre llamadas (cada hilo tiene 100 llamadas)
     *      
     * - Clase Contador:
     *      - Una variable int contador
     *      - Metodo Incrementar contador++
     *      - Metodo Decrementar contador--
     *      - Metodo Mostrar que imprime por consola el valor actual de contador
     */

    internal class Program
    {
        static void Main(string[] args)
        {
            Contador contador = new Contador(0);

            Thread hiloIncrementador = new Thread(() =>
            {
                for(int i = 0; i < 100; i++)
                {
                    Thread.Sleep(100);
                    contador.Incrementar();
                }
            });

            Thread hiloDecrementador = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Thread.Sleep(100);
                    contador.Decrementar();
                }
            });

            hiloIncrementador.Start();
            hiloDecrementador.Start();

            hiloIncrementador.Join();
            hiloDecrementador.Join();

            contador.Mostrar();
        }
    }

    internal class Contador
    {
        internal int contador;
        private readonly object objetoBloqueo = new object();

        public Contador(int cont)
        {
            this.contador = cont;
        }

        public void Incrementar()
        {
            //lock (this)
            lock(objetoBloqueo)
            {
                this.contador++;
            }
        }

        public void Decrementar()
        {
            //lock (this)
            lock(objetoBloqueo)
            {
                this.contador--;
            }
        }

        public void Mostrar()
        {
            Console.WriteLine($"Valor actual del contador: {this.contador}");
        }
    }
}
