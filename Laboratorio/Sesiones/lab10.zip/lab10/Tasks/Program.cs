﻿using System;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;

namespace Tasks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ejemplo01();
            //ejemplo02();
            ejemplo03();
        }



        public static void ejemplo01()
        {
            Task tarea = Task.Run(() =>
            {
                Console.WriteLine("Desde la task ejemplo");
            });

            tarea.Wait(); // se espera a que termine
        }

        public static void ejemplo02()
        {
            Task<int> tarea = Task.Run(() =>
            {
                return Suma(5, 3);
            });

            int resultado = tarea.Result;
            Console.WriteLine("El resultado es: " + resultado);
        }

        private static int Suma(int a, int b)
        {
            return a + b;
        }

        public static void ejemplo03()
        {
            Task<int> tarea = Task.Run(() =>
            {
                return Suma(5, 3);
            });

            Task<int> tarea2 = tarea.ContinueWith((t /* la propia tarea */) => Multiplica(tarea.Result, 2)); // cuando la tarea acabe => la tarea2 va a relevarla 
            tarea2.Wait();
            int resultado = tarea2.Result;
            Console.WriteLine("El resultado es: " + resultado);
        }

        private static int Multiplica(int a, int b)
        {
            return a * b;
        }
    }
}
