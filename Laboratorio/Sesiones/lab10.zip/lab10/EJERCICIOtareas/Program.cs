﻿using System;
using System.Threading.Tasks;

namespace EJERCICIOtareas
{
    /* Usando Task, simular un programa de gestion de descargas de diferentes fuentes de forma asincrona:
     * 
     *      - 3 métodos simulados: DescargarArchivo1, DescargarArchivo2 y DescargarArchivo3, cada uno de ellos simula una descarga.
     *          * Parametro: nombre archivo
     *          * Devuelven: la cantidad de bytes descargados
     *          * Tardan diferentes tiempos en descargar
     *          
     *      - Ejecuta los tres métodos de descarga simultaneamente y espera a que todas las descargas se completen.
     *      - Cuando todas terminen, mostrar el total de bytes descargados.
     */

    internal class Program
    {
        static void Main(string[] args)
        {   
            Task<int> tarea1 = DescargarArchivo1("archivo1.txt");
            Task<int> tarea2 = DescargarArchivo2("archivo2.txt");
            Task<int> tarea3 = DescargarArchivo3("archivo3.txt");

            Task.WaitAll(tarea1, tarea2, tarea3);
            Console.WriteLine($"Total de bytes descargados: {tarea1.Result + tarea2.Result + tarea3.Result} Bytes");
        }

        private static async Task<int> DescargarArchivo1(string nombreArchivo)
        {
            Console.WriteLine("Descargando archivo: " + nombreArchivo + "...");
            await Task.Delay(3000);
            Console.WriteLine("Descarga de " + nombreArchivo + " completada.");
            return 8;
        }

        private static async Task<int> DescargarArchivo2(string nombreArchivo)
        {
            Console.WriteLine("Descargando archivo: " + nombreArchivo + "...");
            await Task.Delay(7000);
            Console.WriteLine("Descarga de " + nombreArchivo + " completada.");
            return 16;
        }

        private static async Task<int> DescargarArchivo3(string nombreArchivo)
        {
            Console.WriteLine("Descargando archivo: " + nombreArchivo + "...");
            await Task.Delay(2000);
            Console.WriteLine("Descarga de " + nombreArchivo + " completada.");
            return 4;
        }
    }   
}
