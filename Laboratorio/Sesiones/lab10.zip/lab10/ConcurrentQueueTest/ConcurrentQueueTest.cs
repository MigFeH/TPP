using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Data;
using System.Threading.Tasks;

namespace TPP.Laboratory.Concurrency.Lab10
{
    [TestClass]
    public class ConcurrentQueueTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            ConcurrentQueue<int> cola = new ConcurrentQueue<int>();

            Task taskEncolar = Task.Run(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    if(i == 1)
                    {
                        Assert.AreEqual(i, cola.Peek());
                    }
                    cola.Enqueue(i + 1);
                }
                Console.WriteLine("Cola tras encolar: " + cola.ToString());
            });

            Task taskDesencolar = Task.Run(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    if(!cola.IsEmpty())
                    {
                        Assert.AreEqual(cola.Peek(), cola.Dequeue());
                    } else
                    {
                        i--;
                    }
                }
                Console.WriteLine("Cola tras desencolar: " + cola.ToString());
            });

            Task.WaitAll(taskEncolar, taskDesencolar);
            Assert.AreEqual(cola.NumberOfElements, (uint)0);
            Console.WriteLine("Cola final: " + cola.ToString());
        }
    }
}
