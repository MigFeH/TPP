﻿using System;
using System.Threading;
using System.Linq;

namespace TPP.Laboratory.Concurrency.Lab10
{
    public class ConcurrentQueue<T>
    {
        private List<T> lista;
        private readonly ReaderWriterLockSlim lockAvanzado = new ReaderWriterLockSlim();

        public uint NumberOfElements
        { 
            get 
            {
                this.lockAvanzado.EnterReadLock(); // entramos en el modo lectura (bloqueamos el recurso pero el resto de hilos pueden leer. No se puede escribir)
                try
                {
                    return lista.NumberOfElements;
                } finally
                {
                    this.lockAvanzado.ExitReadLock(); // salimos del modo lectura
                }
            } 
        }

        // NO DAMOS ACCESO A LA LISTA PORQUE, SI ESTAMOS CON PROGRAMACION POR CONTRATOS, ALGUIEN NOS ACCEDE A LA LISTA, NOS LA MODIFICA Y NOS ESTROPEA LA INVARIANTE
        //public List<T> Cola
        //{
        //    get
        //    {
        //        this.lockAvanzado.EnterReadLock(); // entramos en el modo lectura (bloqueamos el recurso pero el resto de hilos pueden leer. No se puede escribir)
        //        try
        //        {
        //            // se puede devolver una copia pero es mas correcto devolver un iterador y a partir de ahi con linq hacer un toList
        //            //return this.lista.GetEnumerator();
        //            //return this.lista;
        //        } finally
        //        {
        //            this.lockAvanzado.ExitReadLock(); // salimos del modo lectura
        //        }
        //    }
        //}

        public ConcurrentQueue()
        {
            this.lista = new List<T>();
        }

        public ConcurrentQueue(List<T> lista)
        {
            this.lista = lista;
        }

        public bool IsEmpty()
        {
            this.lockAvanzado.EnterReadLock(); // entramos en el modo de lectura (bloqueamos el recurso pero el resto de hilos pueden leer. No se puede escribir)
            try
            {
                return this.lista.IsEmpty();
            }
            finally
            {
                this.lockAvanzado.ExitReadLock(); // salimos del modo lectura
            }
        }

        /// <summary>
        /// Encolar (inserta un objeto al final de la cola)
        /// </summary>
        public void Enqueue(T item)
        {
            this.lockAvanzado.EnterWriteLock(); // entramos en el modo de escritura (solo un hilo está bloqueando. Ningun hilo puede leer ni escribir)
            try
            {
                this.lista.Add(item);
            }
            finally
            {
                this.lockAvanzado.ExitWriteLock(); // salimos del modo de escritura
            }
        }

        /// <summary>
        /// Desencolar (elimina el primer objeto de la cola y lo retorna)
        /// </summary>
        public T Dequeue()
        {
            this.lockAvanzado.EnterWriteLock(); // entramos en el modo de escritura (solo un hilo está bloqueando. Ningun hilo puede leer ni escribir)
            try
            {
                if (!this.lista.IsEmpty())
                {
                    T res = this.lista.GetElement(0);
                    this.lista.RemoveByPosition(0);
                    return res;
                } else
                {
                    throw new Exception("Cola vacía");
                }
            } finally
            {
                this.lockAvanzado.ExitWriteLock(); // salimos del modo de escritura
            }
        }


        /// <summary>
        /// Devuelve el primer objeto de la cola sin eliminarlo
        /// </summary>
        public T Peek()
        {
            this.lockAvanzado.EnterReadLock(); // entramos en el modo de lectura (bloqueamos el recurso pero el resto de hilos pueden leer el objeto. No se puede escribir)
            try
            {
                if (!this.lista.IsEmpty())
                {
                    return this.lista.GetElement(0);
                }
                else
                {
                    throw new Exception("Cola vacía");
                }
            }
            finally
            {
                this.lockAvanzado.ExitReadLock(); // salimos del modo de lectura
            }
        }

        public override string ToString()
        {
            this.lockAvanzado.EnterReadLock(); // entramos en el modo de lectura (bloqueamos el recurso pero el resto de hilos pueden leer el objeto. No se puede escribir)
            try
            {
                return this.lista.ToString();
            }
            finally
            {
                this.lockAvanzado.ExitReadLock(); // salimos del modo de lectura
            }
        }
    }
}
