﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace TPP.Laboratory.Functional.Lab05
{
    public static class Delegates
    {
        //delegate double Function(double x); // definimos un tipo que llamamos Function, y es cualquier metodo estatico o de estancia que reciba un double y devuelva un double; todo metodo que reciba y devuelva double lo podemos llamar con Function

        // entrada (Dominio) ; salida (Rango)
        static IEnumerable<Rango> Map<Dominio, Rango>(this IEnumerable<Dominio> xs, Func<Dominio, Rango> f)
        {
            var ys = new List<Rango>();
            foreach(var x in xs)
            {
                ys.Add(f(x));
            }
            return ys;
        }

        static void Show<T>(this IEnumerable<T> xs)
        {
            foreach (var x in xs)
            {
                Console.Write($"{x} ");
            }
            Console.WriteLine();
        }

        public static Dominio Find<Dominio>(this IEnumerable<Dominio> xs, Predicate<Dominio> p)
        {
            return Filter<Dominio>(xs, p).First();
        }

        // Entrada (dominio) ; Salida (Rango)
        public static IEnumerable<Dominio> Filter<Dominio>(this IEnumerable<Dominio> xs, Predicate<Dominio> p)
        {
            var ys = new List<Dominio>();
            foreach (var x in xs)
            {
                if(p(x))
                {
                    ys.Add(x);
                }
            }
            return ys;
        }

        public static Rango Reduce<Dominio, Rango>(this IEnumerable<Dominio> xs, Func<Dominio, Rango, Rango> f, Rango valorInicial = default(Rango))
        {
            Rango acc = valorInicial;
            foreach(Dominio x in xs)
            {
                acc = f(x, acc);
            }
            return acc;
        }

        static void Main(string[] args)
        {
            //var nums = new double[] { -1, -2, -3, 3, 2, 1 };
            //nums.Map(x => x * x).Show(); // dado un conjunto de valores, mapeamelos con la funcion anonima (no tiene nombre) que hace el cuadrado y muestramelo

            //nums.Map(x => $"{x}").Show();

            //nums.Map(x => x * x).Map(x => $"{x}").Show(); // uniendo (o encadenando) funciones
            //nums.Map(x => $"{x * x}").Show(); // componiendo funciones

            //nums.Map(x => x * x).Map(x => $"{x}").Map(x => x.Length).Show();
            //nums.Map(x => $"{x * x}".Length).Show();
        }
    }
}
