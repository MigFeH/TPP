using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace TPP.Laboratory.Functional.Lab05
{
    [TestClass]
    public class DelegatesTest
    {
        [TestMethod]
        public void TestAngles()
        {
            Angle[] angles = Factory.CreateAngles();
            
            Assert.AreEqual(1, angles.Filter(x => x.Degrees == 90).Count());

            Assert.AreEqual(91, angles.Filter(x => x.Quadrant == 1).Count());
            Assert.IsNotNull(angles.Find(x => x.Quadrant == 1));

            Assert.AreEqual(90, angles.Filter(x => x.Quadrant == 2).Count());
            Assert.IsNotNull(angles.Find(x => x.Quadrant == 2));

            Assert.AreEqual(90, angles.Filter(x => x.Quadrant == 3).Count());
            Assert.IsNotNull(angles.Find(x => x.Quadrant == 3));

            Assert.AreEqual(90, angles.Filter(x => x.Quadrant == 4).Count());
            Assert.IsNotNull(angles.Find(x => x.Quadrant == 4));

            Assert.AreEqual(1, angles.Filter(x => x.Degrees == 90 && x.Quadrant == 1).Count());

            Assert.AreEqual(64980, angles.Reduce((x, acc) => x.Degrees + acc, 0.0));
            Assert.IsNotNull(angles.Reduce((x, acc) => x.Sine() + acc, 0.0));
        }

        [TestMethod]
        public void TestPersons()
        {
            Person[] persons = Factory.CreatePeople();

            Assert.AreEqual(1, persons.Filter(x => x.FirstName.Equals("Miguel")).Count());
            Assert.AreEqual(2, persons.Filter(x => x.FirstName.Equals("Mar�a")).Count());
            Assert.IsNotNull(persons.Find(x => x.FirstName.Equals("Mar�a")));

            Assert.AreEqual(1, persons.Filter(x => x.IDNumber.Contains("K")).Count());
            Assert.AreEqual(2, persons.Filter(x => x.IDNumber.Contains("A")).Count());
            Assert.IsNotNull(persons.Find(x => x.IDNumber.Contains("A")));

            Assert.AreEqual(1, persons.Filter(x => x.FirstName.Equals("Miguel") && x.IDNumber.Contains("T")).Count());

            Assert.AreEqual(2, persons.Filter(x => x.FirstName.Equals("Mar�a")).Reduce((x, acc) => acc+1, 0.0));
            Assert.AreEqual(1, persons.Filter(x => x.FirstName.Equals("Pepe")).Reduce((x, acc) => acc+1, 0.0));
            // metemos el diccionario en el valor por defecto del acumulador
        }
    }
}
