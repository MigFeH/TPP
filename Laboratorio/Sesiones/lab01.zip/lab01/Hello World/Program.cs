﻿using System;

namespace Hello_World // lo mismo que el paquete de java
{
    /// <summary>
    /// La descripcion de la clase
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Documentacion del main de Program
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
