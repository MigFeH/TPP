﻿namespace TPP.Laboratory.Lists.Lab01
{
    internal class Node
    {
        private int info;
        private Node nextNode;

        internal int Info
        {
            get
            {
                return this.info;
            }
            private set
            {
                this.info = value;
            }
        }

        internal Node NextNode
        {
            get
            {
                return this.nextNode;
            }
            set
            {
                this.nextNode = value;
            }
        }

        public Node(int info)
        {
            Info = info;
            this.nextNode = null;
        }
    }

    public class List
    {
        private Node head;
        private uint numberOfElements;
        public uint NumberOfElements // propiedad
        {
            get
            {
                return numberOfElements;
            }

            private set
            {
                numberOfElements = value;
            }
        }

        public List(int info)
        {
            this.head = new Node(info);
            NumberOfElements = 1;
        }

        public void Add(int elem)
        {
            if(numberOfElements == 1)
            {
                this.head.NextNode = new Node(elem);
                NumberOfElements++;
            } else
            {
                this.head.NextNode = RecAdd(this.head.NextNode, elem);
            }
        }

        private Node RecAdd(Node nod, int elem)
        {
            if(nod == null)
            {
                NumberOfElements++;
                return new Node(elem);
            }
            nod.NextNode = RecAdd(nod.NextNode, elem);
            return nod;
        }

        /// <summary>
        /// Borra un nodo y su nodo antecesor hace referencia al nodo antecesor
        /// 
        /// Retorna true si lo encuentra y lo borra
        /// </summary>
        /// <param name="elem"></param>
        /// <returns></returns>
        public bool Remove(int elem)
        {
            if (!Search(this.head, elem))
            {
                return false;
            }

            // Si llega a esta parte del codigo sabemos que el nodo existe
            if(NumberOfElements == 1)
            {
                this.head = null;
                NumberOfElements = 0;
                return true;
            }
            this.head.NextNode = RecRemove(this.head.NextNode, elem);
            return true;
        }

        private Node RecRemove(Node nod, int elem)
        {
            if(nod.Info == elem) // nodo encontrado
            {
                Node aux = nod.NextNode;
                nod = null;
                NumberOfElements--;
                return aux;
            }
            nod.NextNode = RecRemove(nod.NextNode, elem);
            return nod;
        }

        private bool Search(Node nod, int elem)
        {
            if (nod == null) // nodo no encontrado
            {
                return false;
            }
            if (nod.Info == elem) // nodo encontrado
            {
                return true;
            }
            return Search(nod.NextNode, elem);
        }

        /// <summary>
        /// Retorna la info del nodo de la posicion pasada por parametro
        /// </summary>
        /// <param name="elem"></param>
        /// <returns></returns>
        public int GetElement(uint pos)
        {
            if (pos <= this.numberOfElements)
            {
                Node aux = head;
                for (uint i = 0; i < pos; i++)
                {
                    aux = aux.NextNode;
                }
                return aux.Info;
            }
            return -1;
        }

        private Node RecGetElement(Node nod, int elem)
        {
            if (nod.Info == elem)
            {
                return nod;
            }
            return RecGetElement(nod.NextNode, elem);
        }

        override public string ToString()
        {
            string str = "";

            for(uint i = 0; i < NumberOfElements; i++)
            {
                str += "Nodo " + i + "\tInfo: " + GetElement(i) + "\n";
            }

            return str + "Numero de elementos de la estructura: " + NumberOfElements;
        }
    }
}
