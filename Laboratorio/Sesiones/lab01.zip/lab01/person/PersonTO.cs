﻿using System;

namespace TPP.Laboratory.ObjectOrientation.Lab01 {

  /// <summary>
  /// Example class that only holds data: (Data) Transfer Object or Value Object
  /// </summary>
  class PersonTO {
  
    public string FirstName { get; set; }
	
    public string Surname { get; set; }
	
    public string Nationality { get; set; }
	
    public string IDNumber { get; set; }
	
    public DateTime DateOfBirth { get; set; }
	
    public Gender Gender { get; set; }
	
  /* Considering that many fields are optional (IDNumber, Nationality, 
     DateOfBirth and Gender)
   * How many constructors should be defined?   */
    
    //public override bool PersonTO.Equals(PersonTO o)
    //{
    //    return GetHashCode() == o.GetHashCode();
    //}

    //public override int GetHashCode()
    //{
    //        return FirstName.GetHashCode() + Surname.GetHashCode() + Nationality.GetHashCode() + IDNumber.GetHashCode() + DateOfBirth.GetHashCode() + Gender.GetHashCode();
    //}
  }
  
  enum Gender { Male, Female };
  
}

