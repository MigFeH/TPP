﻿using System;

namespace TPP.Laboratory.ObjectOrientation.Lab01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PersonTO p = new PersonTO
            {
                FirstName = "Pepe",
                Surname = "",
            };

            
        }
    }
}
