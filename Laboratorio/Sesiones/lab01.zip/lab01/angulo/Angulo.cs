﻿using System;

namespace TPP.Laboratory.ObjectOrientation.Lab01
{
    public class Angulo
    {
        private double radians;

        public Angulo(double radians)
        {
            this.radians = radians;
        }

        ~Angulo()
        {
            Console.WriteLine("DESTRUCTOR");
        }

        //public double getRadians()
        //{
        //    return this.radians;
        //}

        //public double getDegrees()
        //{
        //    return this.radians / Math.PI * 180;
        //}

        public double Radians
        {
            get
            {
                return radians;
            }
        }

        public double Degrees
        {
            get
            {
                return radians / Math.PI * 180;
            }
        }

        public double sin()
        {
            return Math.Sin(this.radians);
        }

        public double cos()
        {
            return Math.Cos(this.radians);
        }

        public double tan()
        {
            return sin() / cos();
        }
    }
}
