﻿using System;

namespace TPP.Laboratory.Lists.Lab01
{
    class Program
    {
        static void Main(string[] args)
        {
            List l = new List(2);
            Console.WriteLine("Numero de elementos en la lista: {0,0:D}", l.NumberOfElements); // 1
            l.Add(4);
            Console.WriteLine("Numero de elementos en la lista: {0,0:D}", l.NumberOfElements); // 2
            Console.WriteLine("Resultado de borrar un nodo no existente: {0,0:D}", l.Remove(44)); // False
            Console.WriteLine("Resultado de borrar un nodo existente: {0,0:D}, numero de elementos en la lista: {1,0:D}", l.Remove(4), l.NumberOfElements); // True; 1
            Console.WriteLine("Resultado de pedir la informacion de un nodo situado en una posicion no existente: {0,0:D}", l.GetElement(44)); // -1
            Console.WriteLine("Resultado de pedir la informacion de un nodo situado en una posicion existente: {0,0:D}", l.GetElement(0)); // 2
            l.Add(5);
            l.Add(6);
            l.Add(7);
            Console.WriteLine("Numero de elementos en la lista: {0,0:D}", l.NumberOfElements); // 4
            Console.WriteLine("Resultado de borrar un nodo existente: {0,0:D}, numero de elementos en la lista: {1,0:D}", l.Remove(6), l.NumberOfElements); // True; 3
            Console.WriteLine(l.ToString());
        }
    }
}
