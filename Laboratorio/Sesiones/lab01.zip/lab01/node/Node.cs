﻿namespace TPP.Laboratory.Lists.Lab012
{
    internal class Node
    {
        private int info;
        private Node nextNode;

        public Node(int info)
        {
            this.info = info;
            this.nextNode = null;
        }

        public void SetNext(Node next)
        {
            this.nextNode = next;
        }

        public Node GetNext()
        {
            return this.nextNode;
        }

        public int GetInfo()
        {
            return this.info;
        }
    }
}
