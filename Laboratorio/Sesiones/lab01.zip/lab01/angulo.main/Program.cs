﻿using System;

namespace TPP.Laboratory.ObjectOrientation.Lab01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Angulo a = new Angulo(Math.PI);
            Console.WriteLine("Angulo (radians): {0,10:F6}", a.Radians);
            Console.WriteLine("Angulo (degrees): {0,10:F2}", a.Degrees);
            Console.WriteLine("Sin:              {0,10:F}", a.sin());
            Console.WriteLine("Cos:              {0,10:F}", a.cos());
            Console.WriteLine("Tan:              {0,10:F}", a.tan());
        }
    }
}
