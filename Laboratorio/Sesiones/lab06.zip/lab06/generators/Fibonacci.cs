﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TPP.Laboratory.Functional.Lab06 {

    static class Fibonacci {

        static internal IEnumerable<int> InfiniteFibonacci() {
            int first = 1, second = 1;
            while (true) {
                yield return first; // para el productor hasta que se consuma, entonces seguira produciendo; con un yield devuelves un IEnumerator siempre
                int addition = first + second;
                first = second;
                second = addition;
            }
        }

        static public IEnumerable<int> FibonacciLazy(int from, int to)
        {
            return InfiniteFibonacci().Skip(from - 1).Take(to - from + 1);
        }

        static internal IEnumerable<int> FibonacciEager(int from, int to)
        {
            int[] res = new int[to-from+1];
            int first = 1, second = 1;
            int index = 0;
            for(int i = 0; i < to; i++)
            {
                if(i > from && i < to)
                {
                    res[index] = first;
                    index++;
                }
                int addition = first + second;
                first = second;
                second = addition;
            }

            //while (true)
            //{
            //    res[index] = first;
            //    int addition = first + second;
            //    first = second;
            //    second = addition;
            //    if(++index == limite)
            //    {
            //        break;
            //    }
            //}
            return res;
        }

    }

}
