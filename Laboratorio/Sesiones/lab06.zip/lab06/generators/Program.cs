﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace TPP.Laboratory.Functional.Lab06 {

    class Program {
        static void Main() {
            int LIMITE = 10;

            var chrono = new Stopwatch();
            chrono.Start();

            Fibonacci.FibonacciLazy(0, LIMITE);

            chrono.Stop();
            Console.WriteLine("Lazy version. Invocation in {0:N} ticks", chrono.ElapsedTicks);

            chrono.Restart();

            Fibonacci.FibonacciEager(0, LIMITE);

            chrono.Stop();
            Console.WriteLine("No lazy version. Invocation in {0:N} ticks", chrono.ElapsedTicks);
        }
    }
}
