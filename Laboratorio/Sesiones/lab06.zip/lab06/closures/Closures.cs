﻿using System;

namespace TPP.Laboratory.Functional.Lab06 {

    /// <summary>
    /// Try to guess the behavior of this program without running it
    /// </summary>
    class Closures {

        /// <summary>
        /// Version with a single method
        /// </summary>
        static Func<int> Counter1() {
            int counter = 0;
            return () => ++counter;
        }

        static (Func<int> increment, Func<int> decrement, Action<int> assign) /* tupla con esos tipos de datos con nombres */ Counter2(int seed)
        {
            int counter = seed; // ambito
            // devolvemos tres funciones que son las que definimos en la tupla, seran nuestros metodos
            Func<int> increment = () => ++counter; // closure por ser una funcion con ambito (counter)
            Func<int> decrement = () => --counter; // closure por ser una funcion con ambito (counter)
            Action<int> assign = (value) => counter = value; // closure por ser una funcion con ambito (counter)
            return (increment, decrement, assign); // tupla de closures
        }

        static void Main() {
            Func<int> counter = Counter1();
            Console.WriteLine(counter());
            Console.WriteLine(counter());

            Func<int> anotherCounter = Counter1();
            Console.WriteLine(anotherCounter());
            Console.WriteLine(anotherCounter());

            Console.WriteLine(counter());
            Console.WriteLine(counter());


            var c = Counter2(20);
            Console.WriteLine(c.increment());
            Console.WriteLine(c.increment());
            c.assign(30);
            Console.WriteLine(c.decrement());
            Console.WriteLine(c.decrement());
        }
    }

}
