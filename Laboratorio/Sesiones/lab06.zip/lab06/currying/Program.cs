﻿using System;
using System.Collections.Generic;

namespace TPP.Laboratory.Functional.Lab06 {

    static class Program {

        static int Addition(int a, int b) {
            return a + b;
        }

        static Func<int, int> CurryedAdd(int a)
        {
            return b => b + a;
        }

        static IEnumerable<Rango> Map<Dominio, Rango>(this IEnumerable<Dominio> xs, Func<Dominio, Rango> f)
        {
            var ys = new List<Rango>();
            foreach (var x in xs)
            {
                ys.Add(f(x));
            }
            return ys;
        }

        static void Show<T>(this IEnumerable<T> xs)
        {
            foreach (var x in xs)
            {
                Console.Write($"{x} ");
            }
            Console.WriteLine();
        }

        static void Main()
        {
            var nums = new int[] { -1, -2, -3, 3, 2, 1 };
            
            // funcion que devuelve funcion b y hace a+b
            //nums.Map(Addition(1)).Show(); // En Haskell funcionaria
            //nums.Map(partial(Addition,1)).Show(); // En Python funcionaria

            nums.Map(x => Addition(1, x)).Show(); // En C#
            nums.Map(CurryedAdd(1)).Show(); // Otra forma

            
        }

    }
}
