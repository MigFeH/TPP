﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TPP.Laboratory.Functional.Lab08 {

    class Query {

        private Model model = new Model();

        private static void Show<T>(IEnumerable<T> collection) {
            foreach (var item in collection) {
                Console.WriteLine(item);
            }
            Console.WriteLine("Number of items in the collection: {0}.", collection.Count());
        }

        static void Main(string[] args) {
            Query query = new Query();
            query.Query1();
            query.Query2();
            query.Query3();
            query.Query4();
            query.Query5();
            query.Query6();
            query.Homework1();
            query.Homework2();
            query.Homework3();
            query.Homework4();
            query.Homework5();
        }

        private void Query1() {
            // Modify this query to show the names of the employees older than 50 years
            Console.WriteLine("-------------------- Query1 --------------------");
            var employees = model.Employees;
            var res = employees.Where(empl => empl.Age > 50).Select(empl => empl.Name);
            Show(res);
            Console.WriteLine();
        }

        private void Query2() {
            // Show the name and email of the employees who work in Asturias
            Console.WriteLine("-------------------- Query2 --------------------");
            var employees = model.Employees;
            var res = employees.Where(empl => empl.Province == "Asturias").Select(empl => empl.Name + " " + empl.Email);
            Show(res);
            Console.WriteLine();
        }

        // Notice: from now on, check out http://msdn.microsoft.com/en-us/library/9eekhta0.aspx

        private void Query3() {
            // Show the names of the departments with more than one employee 18 years old and beyond; 
            // the department should also have any office number starting with "2.1"
            Console.WriteLine("-------------------- Query3 --------------------");
            var departments = model.Departments;
            var res = departments.Where(dep => dep.Employees.Where(emp => emp.Age >= 18).Count() > 1
                && dep.Employees.Any(emp => emp.Office.Number == "2.1")).Select(dep => dep.Name);
            Show(res);
            Console.WriteLine();
        }

        private void Query4() {
            // Show the phone calls of each employee. 
            // Each line should show the name of the employee and the phone call duration in seconds.
            // nombre del empleado: <nombre>, duracion: <segundos>
            Console.WriteLine("-------------------- Query4 --------------------");
            var employees = model.Employees;
            var calls = model.PhoneCalls;
            var res = employees.Join(calls, e => e.TelephoneNumber, c => c.SourceNumber, (e, c) => new { name = e.Name, duration = c.Seconds });
            foreach(var x in res)
            {
                Console.WriteLine($"Nombre del empleado: {x.name}, duracion: {x.duration}");
            }
            Console.WriteLine();
        }

        private void Query5() {
            // Show, grouped by each province, the name of the employees 
            // (both province and employees must be lexicographically ordered)
            Console.WriteLine("-------------------- Query5 --------------------");
            var employees = model.Employees;
            var res = employees.OrderBy(e => e.Province).ThenBy(e => e.Name).GroupBy(e => e.Province);
            Show(res);
            Console.WriteLine();
        }

        private void Query6()
        {
            // Rank the calls by duration. Show rank position and duration
            Console.WriteLine("-------------------- Query6 --------------------");
            var calls = model.PhoneCalls;
            var res = calls.OrderByDescending(lla => lla.Seconds).Select(lla => lla.Seconds);
            int index = 1;
            foreach(var x in res)
            {
                Console.WriteLine($"Rank position = {index++}, duration = {x}");
            }
            Console.WriteLine();
        }


        /************ Homework **********************************/

        private void Homework1() {
            // Show, ordered by age, the names of the employees in the Computer Science department, 
            // who have an office in the Faculty of Science, 
            // and who have done phone calls longer than one minute
            Console.WriteLine("-------------------- Homework1 --------------------");
            var employees = model.Employees;
            var res = employees
                .Where(e => e.Department.Name == "Computer Science" 
                    && e.Office.Building == "Faculty of Science"
                    && model.PhoneCalls.Any(lla => lla.SourceNumber == e.TelephoneNumber && lla.Seconds > 60))
                .OrderBy(e => e.Age)
                .Select(e => e.Name);
            Show(res);
            Console.WriteLine();
        }

        private void Homework2() {
            // Show the summation, in seconds, of the phone calls done by the employees of the Computer Science department
            Console.WriteLine("-------------------- Homework2 --------------------");
            var employees = model.Employees;
            var res = employees
                .Where(e => e.Department.Name == "Computer Science")
                .Join(model.PhoneCalls, e => e.TelephoneNumber, c => c.SourceNumber, (e,c) => c.Seconds)
                .Sum();
            Console.WriteLine(res);
            Console.WriteLine();
        }

        private void Homework3() {
            // Show the phone calls done by each department, ordered by department names. 
            // Each line must show “Department = <Name>, Duration = <Seconds>”
            Console.WriteLine("-------------------- Homework3 --------------------");
            var employees = model.Employees;
            var res = employees.Join(model.PhoneCalls, e => e.TelephoneNumber, c => c.SourceNumber, (e,c) => new { e.Department.Name, c.Seconds })
                .OrderBy(a => a.Name);
            foreach (var x in res)
            {
                Console.WriteLine($"Department = {x.Name}, Duration = {x.Seconds}");
            }
            Console.WriteLine();
        }

        private void Homework4() {
            // Show the departments with the youngest employee, 
            // together with the name of the youngest employee and his/her age 
            // (more than one youngest employee may exist)
            Console.WriteLine("-------------------- Homework4 --------------------");
            var employees = model.Employees;
            var res = employees
                .Where(em => em.Age == model.Employees.Select(em => em.Age).Min())
                .Select(emp => (emp.Department.Name, emp.Name, emp.Age));
            Show(res);
            Console.WriteLine();
        }

        private void Homework5() {
            // Show the greatest summation of phone call durations, in seconds, 
            // of the employees in the same department, together with the name of the department 
            // (it can be assumed that there is only one department fulfilling that condition)
            Console.WriteLine("-------------------- Homework5 --------------------");
            var departaments = model.Departments;
            var res = departaments
                .Select(dep => 
                    (dep.Employees
                        .Join(model.PhoneCalls, e => e.TelephoneNumber, c => c.SourceNumber, (e,c) => c.Seconds)
                        .Sum(),
                    name:dep.Name))
                .Max();
            Console.WriteLine($"Departament: {res.name}, summation: {res.Item1}");
            Console.WriteLine();
        }


    }

}
