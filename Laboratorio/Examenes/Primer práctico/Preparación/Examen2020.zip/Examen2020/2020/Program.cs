﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using TPP.Laboratory.ObjectOrientation.Lab08;

namespace _2020
{
    public static class Program
    {

        /* Ejercicio 1 (1,5 puntos)
         * 
         * Método extensor de IEnumerable que calcule la diferencia entre dos colecciones representando conjuntos, usando una implementación lazy.
         * 
         * La diferencia entre A y B es el conjunto de los elementos de A que no están en B. B sería un parámetro en la llamada.
         * 
         * Por ejemplo, si las colecciones contienen {15, 18, 6, 14, 1, 7, 8, 2, 3, 0} y {1, 2, 6, 7, 8} el resultado sería {15, 18, 14, 3, 0}.
         * 
         * NOTA: el uso del método predefinido Except no está permitido. */
        public static IEnumerable<T> Diferencia<T>(this IEnumerable<T> A, IEnumerable<T> B)
        {
            // A - B = elementos de A que no están en B
            foreach(T elementoA in A)
            {
                if(!B.Contains(elementoA))
                {
                    yield return elementoA;
                }
            }
        }

        /* Ejercicio 2 (1,75 puntos)
         * 
         * Implementar un generador que reciba como parámetro un real, x.
         * Devuelve una secuencia potencialmente infinita con las potencias de x de exponente 0, 1, 2, etc.
         * 
         * Implementar de modo que se actualice el estado del generador realizando el mínimo número de cálculos.
         * 
         * Usar dicho generador para implementar una función que calcula, usando un bucle adecuado, ∑ ( 1 / 𝑥^𝑖) desde 𝑖=𝑛 hasta 𝑚 incluido,
         * siendo n, m enteros, x real.
         * 
         * Probar con los valores n=1, m=3, x=2.0, se realizaría el cálculo (1/2^1) + (1/2^2) + (1/2^3) = 0.875 */
        public static IEnumerable<double> GeneradorDePotenciasDeBase(double baseDeLaPotencia)
        {
            int exponente = 0;
            while(true)
            {
                yield return Math.Pow(baseDeLaPotencia, exponente++);
            }
        }

        public static double FuncionDelEjercicio2(int desde, int hasta, double baseDeLaPotencia)
        {
            double suma = 0;
            var potenciasBuscadas = GeneradorDePotenciasDeBase(baseDeLaPotencia).Skip(desde).Take(hasta);
            foreach(double potencia in potenciasBuscadas)
            {
                suma += (1 / potencia);
            }
            return suma;
        }

        /* Ejercicio 3 (A)
         * 
         * Dado un valor inicial, impleméntese una clausura que, en cada invocación,
         * devuelva un número aleatorio inferior al anterior devuelto. Una vez llegue al valor
         * cero y lo devuelva, el generador se reiniciará al valor inicial de forma automática. */
        public static Func<int> ClausuraEjercicio3A(int valorLimite)
        {
            Random rd = new Random();
            int nuevoValor = valorLimite;
            return () =>
            {
                if(nuevoValor == 0)
                {
                    nuevoValor = valorLimite;
                }
                nuevoValor = rd.Next(nuevoValor);
                return nuevoValor;
            };
        }

        /* Ejercicio 3 (B)
         * 
         * Cree una versión del anterior que permita tanto reiniciar de forma manual
         * como modificar el valor inicial.
         * 
         * Añádese código en el método Main para probar ambas versiones.
         */
        public static Func<bool,int?,int> ClausuraEjercicio3B(int valorLimite)
        {
            Random rd = new Random();
            int nuevoValor = valorLimite;
            return (realizarReinicio, valorLimiteActualizado) =>
            {
                if(valorLimiteActualizado != null) // si tiene valor (es distinto de null)...
                {
                    valorLimite = valorLimiteActualizado.Value; // actualizamos el valor inicial al nuevo pasado por parámetro de la función
                } else if(realizarReinicio || nuevoValor == 0) // si se pide hacer el reinicio manual o hay que hacer el reinicio automático...
                {
                    nuevoValor = valorLimite;
                }
                nuevoValor = rd.Next(nuevoValor);
                return nuevoValor;
            };
        }

        /* Ejercicio 4
         * 
         * Implementar una clausura que devuelva el siguiente término de la sucesión de Fibonacci
         * cada vez que se invoque la clausura:
         * 
         *      1,1,2,3,5,8,...
         *      
         * Utilícese como base/idea el ejemplo del contador.
         * 
         * NOTA: No es necesario usar la clase Fibonacci PARA NADA, simplemente para
         * aprender a calcular términos de Fibonacci si no se sabe calcularlos.
         */
        public static Func<int> ClausuraEjercicio4()
        {
            int term1 = 1;
            int term2 = 1;
            int contador = 0;
            return () =>
            {
                if(contador <= 1)
                {
                    contador++;
                    return term1; // lo mismo que si retornamos term2
                }
                term2 += term1;
                term1 = term2 - term1;
                return term2;
            };
        }

        /* Ejercicio 5 (A)
         * 
         * Implemente un método extensor Aplicacion de la clase Int32 que reciba:
         * 
         *      Array de funciones con parámetro y retorno de tipo int.
         *      Una variable “máximo” de tipo int.
         *      
         * La función deberá devolver el resultado de ir aplicando cada una de las funciones al resultado de haber aplicado la anterior 
         * (a la primera función se le pasará el propio número).
         * 
         * Si durante el proceso se supera el valor de la variable “máximo”, se devolverá el resultado acumulado hasta el momento.
         * 
         * Pruébese el funcionamiento del método con 3 funciones más o menos simples (1,75 puntos). */
        public static int Aplicacion(this Int32 numero, Func<int, int>[] arrayFunciones, int maximo)
        {
            int acumulado = numero;
            for(int i = 0; i < arrayFunciones.Length; i++)
            {
                if (arrayFunciones[i](acumulado) > maximo)
                {
                    return acumulado;
                }
                acumulado = arrayFunciones[i](acumulado);
            }
            return acumulado;
        }

        /* Ejercicio 5 (B)
         * 
         * Basándose en la misma funcionalidad del anterior y partiendo de un método AplicacionCurrificada que recibirá los 3 parámetros anteriores 
         * (contando el propio número) impleméntese la versión currificada y realícense las pruebas que se consideren adecuadas para demostrar la
         * utilidad de la currificación (0,75 puntos). */
        public static Func<Func<int, int>[],Func<int,int>> AplicacionCurrificada(Int32 numero)
        {
            return (arrayFunciones) => (limite) =>
            {
                int acumulado = numero;
                for(int i = 0; i < arrayFunciones.Length; i++)
                {
                    if (arrayFunciones[i](acumulado) > limite)
                    {
                        return acumulado;
                    }
                    acumulado = arrayFunciones[i](acumulado);
                }
                return acumulado;
            };
        }

        /* Ejercicio 6 (A)
         * 
         * Impleméntese un método Vocales() extensor de la clase String que devuelva la distribución de vocales 
         * en una lista (empleando la de .NET) (1,00 puntos).
         * 
         * Por tanto, “Mensajero”.Vocales() devolverá una lista con 5 entradas (una por vocal) indicando cuántas
         * veces se repite cada vocal. */
        public static System.Collections.Generic.List<int> Vocales(this String cadena)
        {
            char[] vocales = { 'a', 'e', 'i', 'o', 'u' };
            int[] resArray = new int[vocales.Length];
            char[] cadenaSpliteada = cadena.ToLower().ToCharArray();
            for(int i = 0; i < cadenaSpliteada.Length; i++)
            {
                for(int j = 0; j < vocales.Length; j++)
                {
                    if (cadenaSpliteada[i].Equals(vocales[j]))
                    {
                        resArray[j]++;
                    }
                }
            }
            return resArray.ToList();
        }

        
        /* Ejercicio 6 (B)
         * 
         * Sin borrar el código anterior, implemente una funcionalidad similar empleando cláusulas:
         * 
         *      public static Func<int> ClausulaVocales(string cadena).
         *      
         * Cada vez que se invoque a la función devuelta, irá devolviendo un entero con la distribución de la vocal
         * actual (se irán devolviendo en orden: a, e, i, o, u; y vuelta a empezar).
         * 
         * Por tanto, si probamos con ClasulaVocales(“Mensajero”) e invocamos 5 veces a la función devuelta:
         * obtendremos los valores: 1, 2, 0, 1, 0 (1,50 puntos). */
        public static Func<int> ClausulaVocales(string cadena)
        {
            int contador = 0;
            char[] vocales = { 'a', 'e', 'i', 'o', 'u' };
            int[] resArray = new int[vocales.Length];
            char[] cadenaSpliteada = cadena.ToLower().ToCharArray();
            for (int i = 0; i < cadenaSpliteada.Length; i++)
            {
                for (int j = 0; j < vocales.Length; j++)
                {
                    if (cadenaSpliteada[i].Equals(vocales[j]))
                    {
                        resArray[j]++;
                    }
                }
            }
            return () =>
            {
                if(contador == resArray.Length)
                {
                    contador = 0;
                }
                return resArray[contador++];
            };
        }

        /* Ejercicio 7
         * 
         * Impleméntese una función de orden superior genérica que reciba (1,75 puntos):
         * 
         *      Un IEnumerable de Predicados
         *      Un IEnumerable de elementos
         *      
         * Devolverá un IDictionary con la siguiente estructura:
         * 
         *      Como claves utilizará el número de predicados incumplidos.
         *      Para cada entrada tendrá una IList con los elementos que han incumplido ese total de predicados.
         *      
         * A través de un proyecto de test, pruébese la funcionalidad del método empleando un array de 1000 palabras de longitud 2-4 caracteres y
         * usando de predicados:
         *      uno para saber si la longitud de la palabra es impar
         *      otro para saber si la longitud de la palabra es igual que 4 (0,75 puntos).
         */
        public static IDictionary<int,IList<T>> FuncionOrdenSuperiorEj7<T>(IEnumerable<Predicate<T>> predicados, IEnumerable<T> elementos)
        {
            IDictionary<int, IList<T>> res = new Dictionary<int, IList<T>>();

            for(int i = 0; i < elementos.Count(); i++)
            {
                res.Add(i, new System.Collections.Generic.List<T>());
            }

            for(int i)

            return res;
        }
        

        /* Ejercicio 8
         * 
         * A tu implementación de List<T> realizada en clase, debes añadir un método DeleteIfFollowing. 
         * 
         * Ese método recibe como parámetro un delegado de tipo Func<T, T,bool>, el cual se aplicará a cada elemento
         * de la lista (excepto el último) y su sucesor.
         * 
         * Si devuelve true, entonces se eliminará el sucesor y se volverá a probar con el nuevo sucesor.
         * 
         * Este método debe modificar la lista actual.
         * 
         * Dada una lista de enteros, prueba su funcionamiento eliminado (DeleteIfFollowing) elementos si estos son mayores que el actual o
         * cualquier otro criterio que se te ocurra.
         * Para ello escribe un fragmento de código en el método Ejercicio3 del proyecto ejercicios. */

        static void Main(string[] args)
        {
            Console.WriteLine("----------------------- Ej 1 -----------------------");
            IEnumerable<int> conjA = new System.Collections.Generic.List<int> { 15, 18, 6, 14, 1, 7, 8, 2, 3, 0 };
            IEnumerable<int> conjB = new System.Collections.Generic.List<int> { 1, 2, 6, 7, 8 };
            var diferencias = conjA.Diferencia(conjB); // obtenemos las diferencias y las vamos procesando según las vamos necesitando (esto es lazy)
            foreach(var item in diferencias)
            {
                Console.Write($"{item} ");
            }
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 2 -----------------------");
            int desde = 1; // el n
            int hasta = 3; // el m
            double x = 2.0;
            Console.WriteLine($"Resultado obtenido para los valores: n={desde}, m={hasta}, x={x}: {FuncionDelEjercicio2(desde, hasta, x)}");
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 3(A) -----------------------");
            var funcionObtenidaA = ClausuraEjercicio3A(100); // almacenamos la función obtenida
            for(int i = 0; i < 6; i++)
            {
                Console.WriteLine($"Valor obtenido con límite 100: {funcionObtenidaA()}");
            }
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 3(B) -----------------------");
            var funcionObtenidaB = ClausuraEjercicio3B(100); // almacenamos la función obtenida
            for(int i = 0; i < 6; i++)
            {
                Console.WriteLine($"Valor obtenido con límite 100, sin reinicio manual ni valor inicial cambiado: {funcionObtenidaB(false,null)}");
            }
            Console.WriteLine();
            Console.WriteLine($"Valor obtenido con límite 100, CON reinicio manual y sin valor inicial cambiado: {funcionObtenidaB(true, null)}");
            for(int i = 0; i < 6; i++)
            {
                Console.WriteLine($"Valor obtenido con límite 100, sin reinicio manual ni valor inicial cambiado: {funcionObtenidaB(false, null)}");
            }
            Console.WriteLine();
            Console.WriteLine($"Valor obtenido con límite 100, sin reinicio manual y CON valor inicial cambiado a 50: {funcionObtenidaB(false, 50)}");
            for(int i = 0; i < 6; i++)
            {
                Console.WriteLine($"Valor obtenido con límite 50, sin reinicio manual ni valor inicial cambiado: {funcionObtenidaB(false, null)}");
            }
            Console.WriteLine();
            Console.WriteLine($"Valor obtenido con límite 50, CON reinicio manual y CON valor inicial cambiado a 75: {funcionObtenidaB(true, 75)}");
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine($"Valor obtenido con límite 75, sin reinicio manual ni valor inicial cambiado: {funcionObtenidaB(false, null)}");
            }
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 4 -----------------------");
            var funcionObtenida = ClausuraEjercicio4();
            for(int i = 0; i < 6; i++)
            {
                Console.WriteLine($"Término de la sucesión de Fibonacci obtenido = {funcionObtenida()}");
            }
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 5(A) -----------------------");
            Func<int, int> funcion01 = (numero) => numero + 10;
            Func<int, int> funcion02 = (numero) => numero + 20;
            Func<int, int> funcion03 = (numero) => numero + 30;
            Func<int, int>[] arrayFunciones = { funcion01, funcion02, funcion03 };
            Int32 numero = 1;
            Console.WriteLine($"Resultado de Aplicacion con un numero = {numero} y límite = 30: {numero.Aplicacion(arrayFunciones, 30)}");
            Console.WriteLine($"Resultado de Aplicacion con un numero = {numero} y límite = 31: {numero.Aplicacion(arrayFunciones, 31)}");
            Console.WriteLine($"Resultado de Aplicacion con un numero = {numero} y límite = 60: {numero.Aplicacion(arrayFunciones, 60)}");
            Console.WriteLine($"Resultado de Aplicacion con un numero = {numero} y límite = 61: {numero.Aplicacion(arrayFunciones, 61)}");
            Console.WriteLine($"Resultado de Aplicacion con un numero = {numero} y límite = 81: {numero.Aplicacion(arrayFunciones, 81)}");
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 5(B) -----------------------");
            var res01 = AplicacionCurrificada(numero);
            var res02 = res01(arrayFunciones);
            Console.WriteLine($"Resultado de AplicacionCurrificada con un numero = {numero} y límite = 30: {res02(30)}");
            Console.WriteLine($"Resultado de AplicacionCurrificada con un numero = {numero} y límite = 31: {res02(31)}");
            Console.WriteLine($"Resultado de AplicacionCurrificada con un numero = {numero} y límite = 60: {res02(60)}");
            Console.WriteLine($"Resultado de AplicacionCurrificada con un numero = {numero} y límite = 61: {res02(61)}");
            Console.WriteLine($"Resultado de AplicacionCurrificada con un numero = {numero} y límite = 81: {res02(81)}");
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 6(A) -----------------------");
            System.Collections.Generic.List<int> distribucionVocales01 = "Mensajero".Vocales();
            System.Collections.Generic.List<int> distribucionVocales02 = "aaaaaa".Vocales();
            System.Collections.Generic.List<int> distribucionVocales03 = "eeeeee".Vocales();
            System.Collections.Generic.List<int> distribucionVocales04 = "iiiiii".Vocales();
            System.Collections.Generic.List<int> distribucionVocales05 = "oooooo".Vocales();
            System.Collections.Generic.List<int> distribucionVocales06 = "uuuuuu".Vocales();
            System.Collections.Generic.List<int>[] arrayDistribucionesVocales = { distribucionVocales01, distribucionVocales02, distribucionVocales03, distribucionVocales04, distribucionVocales05, distribucionVocales06 };

            for(int i = 0; i < arrayDistribucionesVocales.Length; i++)
            {
                for(int j = 0; j < arrayDistribucionesVocales[i].Count; j++)
                {
                    Console.Write($" {arrayDistribucionesVocales[i][j]}");
                }
                Console.WriteLine();
            }
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 6(B) -----------------------");
            var funcionRetornada = ClausulaVocales("Mensajero"); // almacenamos la función retornada
            Console.WriteLine("Chequeo del funcionamiento realizado mediante asertos");
            Debug.Assert(1 == funcionRetornada(), "Valor retornado incorrecto");
            Debug.Assert(2 == funcionRetornada(), "Valor retornado incorrecto");
            Debug.Assert(0 == funcionRetornada(), "Valor retornado incorrecto");
            Debug.Assert(1 == funcionRetornada(), "Valor retornado incorrecto");
            Debug.Assert(0 == funcionRetornada(), "Valor retornado incorrecto");
            Debug.Assert(1 == funcionRetornada(), "Valor retornado incorrecto");
            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 7 -----------------------");

            Console.WriteLine();

            Console.WriteLine("----------------------- Ej 8 -----------------------");
            TPP.Laboratory.ObjectOrientation.Lab08.List<int> listaDelEj08 = new TPP.Laboratory.ObjectOrientation.Lab08.List<int>();
            listaDelEj08.Add(9);
            listaDelEj08.Add(2);
            listaDelEj08.Add(4);
            listaDelEj08.Add(19);
            listaDelEj08.Add(81);
            Console.WriteLine(listaDelEj08.ToString());
            Console.WriteLine();
            listaDelEj08.DeleteIfFollowing((elem1, elem2) => { return elem1 < elem2; });
            Console.WriteLine(listaDelEj08.ToString());
            Console.WriteLine();
            

        }
    }
}
