﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace TPP.Laboratory.ObjectOrientation.Lab08
{
    public class Node<T>
    {
        public T Info { get; private set; }
        internal Node<T> NextNode { get; set; }

        public Node()
        {
            NextNode = null;
        }

        public Node(T info)
        {
            UpdateInfo(info);
            NextNode = null;
        }

        public void UpdateInfo(T info)
        {
            Info = info;
        }
    }

    public class List<T> : IEnumerable<T>
    {
        private Node<T> head;
        public uint NumberOfElements { get; private set; }

        public List()
        {
            head = new Node<T>();
            NumberOfElements = 0;

            Invariantes();

            Debug.Assert(head != null, "Estado no valido de la cabecera de la lista (cabecera null)");
            Debug.Assert(NumberOfElements == 0, "Inicializacion no valida del numero de elementos de la lista");
        }

        private void Invariantes()
        {
            Debug.Assert(this != null, "Estado de la lista no valido");
        }

        public void Add(T info)
        {
            // precondiciones
            if (info == null)
            {
                throw new ArgumentException("Elemento a agregar no valido (elemento null)");
            }

            Invariantes();

            uint contadorNumeroElementos = NumberOfElements;

            if (NumberOfElements == 0)
            {
                head = new Node<T>(info);
                NumberOfElements++;
            }
            else
            {
                head.NextNode = RecAdd(head.NextNode, info);
            }

            Invariantes();

            // postcondiciones
            Debug.Assert(head != null, "Estado no valido de la cabecera de la lista (cabecera null)");
            Debug.Assert(NumberOfElements == contadorNumeroElementos + 1, "Actualizacion incorrecta del numero de elementos de la lista");
        }

        private Node<T> RecAdd(Node<T> nod, T info)
        {
            Invariantes();

            if (nod == null)
            {
                NumberOfElements++;
                return new Node<T>(info);
            }
            nod.NextNode = RecAdd(nod.NextNode, info);

            Invariantes();

            return nod;
        }

        /// <summary>
        /// Borra un nodo y su nodo antecesor hace referencia al nodo antecesor.
        /// Retorna true si lo encuentra y lo borra
        /// </summary>
        public bool Remove(T info)
        {
            // precondiciones
            if (info == null)
            {
                throw new ArgumentException("Elemento a eliminar no valido (elemento null)");
            }
            else if (NumberOfElements == 0)
            {
                throw new Exception("No es posible la eliminacion por estar la lista vacia");
            }

            Invariantes();

            if (!Search(info))
            {
                return false;
            }

            uint contadorNumeroElementos = NumberOfElements;

            // Si llega a esta parte del codigo sabemos que el nodo existe

            if (head.Info.Equals(info)) // nodo encontrado
            {
                if (NumberOfElements == 1)
                {
                    head = null;
                    NumberOfElements = 0;

                    Invariantes();

                    // postcondiciones
                    Debug.Assert(head == null, "Cabecera no eliminada correctamente");
                    Debug.Assert(NumberOfElements == 0, "Numero de elementos de la lista no actualizado correctamente");

                    return true;
                }

                head = head.NextNode;
                NumberOfElements--;

                Invariantes();

                // postcondiciones
                Debug.Assert(NumberOfElements == contadorNumeroElementos - 1, "Numero de elementos de la lista no actualizado correctamente");

                return true;
            }

            head.NextNode = RecRemove(head.NextNode, info);

            Invariantes();

            // postcondiciones
            Debug.Assert(NumberOfElements == contadorNumeroElementos - 1, "Numero de elementos de la lista no actualizado correctamente");

            return true;
        }

        private Node<T> RecRemove(Node<T> nod, T info)
        {
            Invariantes();

            if (nod.Info.Equals(info)) // nodo encontrado
            {
                Node<T> aux = nod.NextNode;
                nod = null;
                NumberOfElements--;
                return aux;
            }
            nod.NextNode = RecRemove(nod.NextNode, info);

            Invariantes();

            return nod;
        }

        public bool Search(T info)
        {
            // precondiciones
            if (info == null)
            {
                throw new ArgumentException("Elemento a buscar no valido (elemento null)");
            }
            else if (NumberOfElements == 0)
            {
                throw new Exception("No es posible la busqueda por estar la lista vacia");
            }

            Invariantes();

            return RecSearch(head, info);
        }

        private bool RecSearch(Node<T> nod, T info)
        {
            Invariantes();

            if (nod == null) // nodo no encontrado
            {
                return false;
            }
            if (nod.Info.Equals(info)) // nodo encontrado
            {
                return true;
            }

            Invariantes();

            return RecSearch(nod.NextNode, info);
        }

        /// <summary>
        /// Retorna la info del nodo de la posicion pasada por parametro
        /// </summary>
        public T GetElement(uint pos)
        {
            // precondiciones
            if (NumberOfElements == 0)
            {
                throw new Exception("No es posible la busqueda por estar la lista vacia");
            }
            else if (pos >= NumberOfElements)
            {
                throw new IndexOutOfRangeException("Valor fuera de rango");
            }

            Invariantes();

            Node<T> aux = head;
            for (uint i = 0; i < pos; i++)
            {
                aux = aux.NextNode;
            }

            T res = aux.Info;

            Invariantes();

            // postcondiciones
            Debug.Assert(res != null, "Info del elemento a retornar no valida (info null)");

            return res;
        }

        private Node<T> RecGetElement(Node<T> nod, T elem)
        {
            Invariantes();

            if (nod.Info.Equals(elem))
            {
                return nod;
            }

            Invariantes();

            return RecGetElement(nod.NextNode, elem);
        }

        override public string ToString()
        {
            Invariantes();

            string str = "";

            for (uint i = 0; i < NumberOfElements; i++)
            {
                str += "Nodo " + i + "\tInfo: " + GetElement(i) + "\n";
            }

            str += "Numero de elementos de la estructura: " + NumberOfElements;

            Invariantes();

            // postcondiciones
            Debug.Assert(str != null, "Cadena a ser retornada no valida (cadena null)");
            Debug.Assert(str.Length != 0, "Cadena a ser retornada no valida (cadena de longitud 0)");

            return str;
        }

        public bool Contains(T info)
        {
            // precondiciones
            if (info == null)
            {
                throw new ArgumentException("Elemento a buscar no valido (elemento null)");
            }
            else if (NumberOfElements == 0)
            {
                throw new Exception("No es posible la busqueda por estar la lista vacia");
            }

            Invariantes();

            bool res = Search(info);

            Invariantes();

            return res;
        }

        public void Clear()
        {
            Invariantes();

            head = null;
            NumberOfElements = 0;

            Invariantes();
            Debug.Assert(head == null && NumberOfElements == 0, "Reseteo de la coleccion no logrado");
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new ListEnumerator<T>(head);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return new ListEnumerator<T>(head);
        }

        /// <summary>
        /// Retorna la info del primer nodo que cumpla la condicion que recibe como parametro un nodo
        /// </summary>
        public T Find(Predicate<Node<T>> condicion)
        {
            if (NumberOfElements == 0)
            {
                throw new Exception("Coleccion vacia");
            }
            else if (condicion == null)
            {
                throw new ArgumentNullException("Predicado a evaluar null");
            }
            Invariantes();

            List<T> res = Filter(condicion);
            if(res != null)
            {
                Invariantes();
                return res.head.Info;
            }
            throw new Exception("Elemento no encontrado");
        }

        /// <summary>
        /// Filtra los elementos de la lista por una condicion que recibe como parametro un nodo
        /// Retorna el filtrado como una nueva lista
        /// </summary>
        public List<T> Filter(Predicate<Node<T>> condicion)
        {
            if (NumberOfElements == 0)
            {
                throw new Exception("Coleccion vacia");
            }
            else if (condicion == null)
            {
                throw new ArgumentNullException("Predicado a evaluar null");
            }
            Invariantes();

            List<T> ys = new List<T>();
            Node<T> aux = head;
            while (aux != null)
            {
                if (condicion(aux))
                {
                    ys.Add(aux.Info);
                }
                aux = aux.NextNode;
            }

            Invariantes();
            return ys;
        }

        /// <summary>
        /// Reduce los elementos de la lista mediante una funcion que recibe los elementos con los que opera (nodos),
        /// el acumulador y retorna el acumulador
        /// </summary>
        public TS Reduce<TS>(Func<Node<T>, TS, TS> operacion, TS semilla = default)
        {
            if (NumberOfElements == 0)
            {
                throw new Exception("Coleccion vacia");
            }
            else if (operacion == null)
            {
                throw new ArgumentNullException("Operacion a realizar null");
            }
            Invariantes();

            TS acc = semilla;
            Node<T> aux = head;
            while (aux != null)
            {
                acc = operacion(aux, acc);
                aux = aux.NextNode;
            }

            Invariantes();
            return acc;
        }

        /// <summary>
        /// Invierte la lista
        /// </summary>
        public List<T> Invert()
        {
            if (NumberOfElements == 0)
            {
                throw new Exception("Coleccion vacia");
            }
            Invariantes();

            List<T> res = new List<T>();
            Node<T>[] arrayNodos = ToArray();

            // rellenar la lista a retornar con los nodos del array de nodos pero con un recorrido inverso
            for (int i = arrayNodos.Length - 1; i > -1; i--)
            {
                res.Add(arrayNodos[i].Info);
            }

            Invariantes();
            Debug.Assert(res != null, "Fallo en el retorno de la lista invertida");
            return res;
        }

        /// <summary>
        /// Transforma la lista en un array de nodos de tipo generico
        /// </summary>
        public Node<T>[] ToArray()
        {
            Node<T>[] res = new Node<T>[NumberOfElements];
            Node<T> aux = head;

            int index = -1;

            // rellenar el array de nodos con los nodos de la lista
            while (index < res.Length && aux != null)
            {
                res[++index] = aux;
                aux = aux.NextNode;
            }

            return res;
        }

        /// <summary>
        /// Hace la funcion del Map recibiendo una operacion que recibe un nodo
        /// </summary>
        public List<TS> Map<TS>(Func<Node<T>, TS> operacion)
        {
            if (NumberOfElements == 0)
            {
                throw new Exception("Coleccion vacia");
            }
            else if (operacion == null)
            {
                throw new ArgumentNullException("Operacion a realizar null");
            }
            Invariantes();

            List<TS> res = new List<TS>();
            Node<T> aux = head;
            while (aux != null)
            {
                res.Add(operacion(aux));
                aux = aux.NextNode;
            }

            Invariantes();
            Debug.Assert(res != null, "Fallo en el retorno de la lista mapeada");
            return res;
        }

        /// <summary>
        /// Realiza una operacion sobre cada nodo de la lista haciendo uso de un for each
        /// </summary>
        public void ForEach(Action<Node<T>> operacion)
        {
            if (NumberOfElements == 0)
            {
                throw new Exception("Coleccion vacia");
            }
            else if (operacion == null)
            {
                throw new ArgumentNullException("Accion a realizar null");
            }
            Invariantes();

            Node<T> aux = head;
            while (aux != null)
            {
                operacion(aux);
                aux = aux.NextNode;
            }

            Invariantes();
        }

        public bool RemoveByPosition(uint pos)
        {
            // precondiciones
            if (pos >= NumberOfElements)
            {
                throw new ArgumentException("Posicion fuera de limites");
            }
            else if (NumberOfElements == 0)
            {
                throw new Exception("No es posible la eliminacion por estar la lista vacia");
            }

            Invariantes();
            uint contadorNumeroElementos = NumberOfElements;

            Node<T>[] arrayDeLaLista = ToArray();
            if(pos == 0)
            {
                if(NumberOfElements == 1)
                {
                    head = null;
                } else
                {
                    head = arrayDeLaLista[1];
                }
                NumberOfElements--;
            } else
            {
                arrayDeLaLista[pos - 1].NextNode = arrayDeLaLista[pos].NextNode; // el recolector de basura ya eliminará el nodo suelto
                NumberOfElements--;
            }

            Invariantes();

            // postcondiciones
            Debug.Assert(NumberOfElements == contadorNumeroElementos - 1, "Numero de elementos de la lista no actualizado correctamente");

            return true;
        }

        // --------------------------------------- IMPLEMENTACIONES DE EXAMENES ANTERIORES --------------------------------------- //
        //public delegate bool DelegadoEj8(T current, T next); // declaramos todas las funciones que retornan booleano y reciben dos parametros de tipo T como una funcion llamada DelegadoEj8 (AL FINAL NO HAY QUE CREAR UN DELEGADO)

        /* Ejercicio 8
         * 
         * A tu implementación de List<T> realizada en clase, debes añadir un método DeleteIfFollowing. 
         * 
         * Ese método recibe como parámetro un delegado de tipo Func<T, T,bool>, el cual se aplicará a cada elemento
         * de la lista (excepto el último) y su sucesor.
         * 
         * Si devuelve true, entonces se eliminará el sucesor y se volverá a probar con el nuevo sucesor.
         * 
         * Este método debe modificar la lista actual.
         * 
         * Dada una lista de enteros, prueba su funcionamiento eliminado (DeleteIfFollowing) elementos si estos son mayores que el actual o
         * cualquier otro criterio que se te ocurra.
         * Para ello escribe un fragmento de código en el método Ejercicio3 del proyecto ejercicios. */
        public void DeleteIfFollowing(Func<T,T,bool> operacion)
        {
            // la funcion se le aplica a cada elemento de la lista (excepto el último) y su sucesor
            for(uint i = 0; i < NumberOfElements-1; i++)
            {
                while(i + 1 < NumberOfElements && operacion(GetElement(i), GetElement(i + 1)))
                {
                    // se elimina al sucesor y se volverá a probar con el nuevo sucesor
                    RemoveByPosition(i+1);                    
                }
            }
        }
    }
}

