﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace TPP.Laboratory.ObjectOrientation.Lab08
{
    internal class ListEnumerator<T> : IEnumerator<T>
    {
        private Node<T> head;
        private Node<T> nodo;

        public ListEnumerator(Node<T> head)
        {
            if (head == null)
            {
                throw new ArgumentException("Cabecera de coleccion no valida (cabecera null)");
            }

            this.head = head;
            nodo = head;
        }

        public T Current { get { return nodo.Info; } }

        object IEnumerator.Current { get { return nodo.Info; } }

        public void Dispose()
        {
            // no implementamos nada
        }

        public bool MoveNext()
        {
            if (nodo.NextNode != null)
            {
                nodo = nodo.NextNode;
                return true;
            }
            return false;
        }

        public void Reset()
        {
            nodo = head;
        }
    }
}